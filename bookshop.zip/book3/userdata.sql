use userdata;
select * from users;
create table users(
SlNo INT UNSIGNED NOT NULL AUTO_INCREMENT,
primary key(SlNo),
fullName VARCHAR(30) NOT NULL,
Email VARCHAR(30) NOT NULL,
userName VARCHAR(30) NOT NULL,
password VARCHAR(30) NOT NULL,
UNIQUE KEY (userName)
);
use userdata;
select * from users;

INSERT into users VALUE(
1,'valir','valir@gmail','valir123','abc123'
);

create table customer(
id INT UNSIGNED NOT NULL AUTO_INCREMENT,
primary key(id),
username VARCHAR(30) NOT NULL,
email VARCHAR(30) NOT NULL,
address VARCHAR(100) NOT NULL,
phone VARCHAR(30) NOT NULL,
password VARCHAR(30) NOT NULL,
UNIQUE KEY (username)
);

use userdata;
select * from customer;

SELECT id, username, email, address, phone, password, age FROM customer;

ALTER TABLE customer
DROP COLUMN age;

ALTER TABLE customer
ADD age INT NOT NULL;

ALTER TABLE customer
MODIFY age INT NOT NULL;

use userdata;select * from customer;
/*drop table book; */

create table admin(
username VARCHAR(30) NOT NULL,
password VARCHAR(30) NOT NULL,
UNIQUE KEY (username),
UNIQUE KEY (password),
primary key(username)
);

select * from admin;

create table book(
isbn INT NOT NULL AUTO_INCREMENT,
primary key(isbn),
title VARCHAR(30) NOT NULL,
author VARCHAR(30) NOT NULL,
publisher VARCHAR(100) NOT NULL,
price DECIMAL(10,2) NOT NULL,
keyword VARCHAR(100) NOT NULL,
category VARCHAR(100) NOT NULL,
description VARCHAR(400) NOT NULL,
stock int NOT NULL,
image VARCHAR(100) NOT NULL,
UNIQUE KEY (isbn)
);

use userdata;
select * from book;

select * from book where title='burung' or keyword= 'burung' ;

insert into book values 
('6482','Takdir: Cahaya ','punai','bob','37.50','cahaya','fiction','Takdir: Cahaya Yang Tidak Terpadam ialah sebuah novel remaja karya penulis muda Hilal Asyraf. ','100','null'),
('6483','Frankenstein','punai','koka','17.90','Frankenstein','horror','Semasa tahun 1880-an, kepengarangan dari Mary Shelley (1797 - 1851) mengenai Frankenstein dipersoalkan. persepsi yang tidak adil terhadap seorang wanita yang merupakan seorang penulis profesional.','100','null');


insert into book values 
('6484','Ikan ','punai','bob','57.50','cahaya','education','Takdir: Cahaya Yang Tidak Terpadam ialah sebuah novel remaja karya penulis muda Hilal Asyraf. ','100','book_5.jepg'),
('6485','Ineresting topic','tupai','koka','87.90','Frankenstein','education','Semasa tahun 1880-an, kepengarangan dari Mary Shelley (1797 - 1851) mengenai .','100','book_6.jpeg');
UPDATE `userdata`.`book` SET `image` = 'book_8.jpg' WHERE (`isbn` = '6487');


insert into book values 
('6486','Semutt ','punai','bob','77.50','cahaya','education','Takdir: Cahaya Yang Tidak Terpadam ialah sebuah novel remaja karya penulis muda Hilal Asyraf. ','100','book_7.jpg'),
('6487','Aim Assistance','tupai','koka','27.90','Frankenstein','education','Semasa tahun 1880-an, kepengarangan dari Mary Shelley (1797 - 1851) mengenai .','100','book_8.jpg');


UPDATE `userdata`.`book` SET `image` = 'mouse.jpeg' WHERE (`isbn` = '6483');

UPDATE `userdata`.`book` SET `image` = 'k1.jpeg' WHERE (`isbn` = '6482');

UPDATE `userdata`.`book` SET `image` = 'k1.jpeg' WHERE (`isbn` = '6481');
UPDATE `userdata`.`book` SET `image` = 'k2.jpeg' WHERE (`isbn` = '6482');
UPDATE `userdata`.`book` SET `image` = 'k3.jpeg' WHERE (`isbn` = '6483');
UPDATE `userdata`.`book` SET `image` = 'k4.jpeg' WHERE (`isbn` = '6484');

UPDATE book
SET image = ""
WHERE isbn = "FOL3463";


ALTER TABLE book
MODIFY image VARCHAR(400);

ALTER TABLE book
MODIFY description VARCHAR(1000);
UPDATE `userdata`.`book` SET `image` = 'ant' WHERE (`isbn` = '6485');
UPDATE `userdata`.`book` SET `image` = 'book_6.jpeg' WHERE (`isbn` = '6485');
UPDATE `userdata`.`book` SET `image` = 'shoes.jpeg' WHERE (`isbn` = '6486');
UPDATE `userdata`.`book` SET `image` = 'arrival_4.jpeg' WHERE (`isbn` = '6481');
UPDATE `userdata`.`book` SET `image` = 'arrival_5.jpeg' WHERE (`isbn` = '6482');
UPDATE `userdata`.`book` SET `image` = 'arrival_6.jpeg' WHERE (`isbn` = '6483');
UPDATE `userdata`.`book` SET `image` = 'arrival_9.jpeg' WHERE (`isbn` = '6484');
UPDATE `userdata`.`book` SET `image` = 'shoe2.jpeg' WHERE (`isbn` = '6487');


create table payment(
isbn INT NOT NULL ,
payid VARCHAR(30) NOT NULL,
id INT UNSIGNED NOT NULL ,
paytype VARCHAR(100) NOT NULL,
totprice DECIMAL(10,2) NOT NULL, 
date DATE,
quantity INT NOT NULL,
FOREIGN KEY (id) REFERENCES customer(id),
FOREIGN KEY (isbn) REFERENCES book(isbn),
primary key(payid)
);

ALTER TABLE payment
ADD date DATE;

ALTER TABLE payment
ADD quantity INT NOT NULL ;

use userdata ;
select* from payment;
 

SELECT id, username, email, address, phone, password, age FROM customer;

use userdata;
CREATE TABLE cart (
  cart_id INT AUTO_INCREMENT PRIMARY KEY,
  username VARCHAR(30) NOT NULL,
  isbn INT NOT NULL,
  quantity INT NOT NULL,
  bookPrice DECIMAL(10,2) NOT NULL
);

use userdata;
select * from cart;

ALTER TABLE cart 
ADD bookPrice DECIMAL(10,2) NOT NULL;

use userdata;
select * from book;
SELECT cart.isbn, cart.quantity, book.title, book.price
FROM cart
JOIN book ON cart.isbn = book.isbn
WHERE username = 'ibrahim';

use userdata;
INSERT INTO cart (username,isbn,quantity,bookPrice) VALUES ("ibrahim","6482","5","37.50");


SELECT title,price FROM book where isbn= 6482;


use userdata;
CREATE TABLE orders (
  orderId INT AUTO_INCREMENT PRIMARY KEY,
  payId INT NOT NULL,
  username VARCHAR(50) NOT NULL,
  isbn VARCHAR(100) NOT NULL,
  date DATE NOT NULL,
  total DECIMAL(10,2) NOT NULL,
  status VARCHAR(40) NOT NULL
);
select * from orders;

DELETE FROM orders
WHERE username = 'ibrahim';
/*
ALTER TABLE table_name
DROP COLUMN column_name;
*/

ALTER TABLE orders
MODIFY isbn VARCHAR(100);



ALTER TABLE orders
DROP FOREIGN KEY orders_ibfk_2;

ALTER TABLE orders
DROP COLUMN isbn;

ALTER TABLE orders 
ADD isbn VARCHAR(100);


CREATE INDEX idx_cart_quantity ON cart (quantity);


use userdata;
CREATE TABLE ordersDetail (
  orderDetailId INT AUTO_INCREMENT PRIMARY KEY,
  orderId INT NOT NULL,
  username VARCHAR(50) NOT NULL,
  fullname VARCHAR(300) NOT NULL,
  isbn INT NOT NULL,
  quantity INT NOT NULL, 
  email VARCHAR(30) NOT NULL,
  address VARCHAR(100) NOT NULL,
  phone VARCHAR(30) NOT NULL,
  linePrice DECIMAL(10,2) NOT NULL,
  payType VARCHAR(30) NOT NULL,
  cardId VARCHAR(30) NOT NULL
  
);
select * from ordersDetail;



select * from orders;

DELETE FROM orders
WHERE username = 'ibrahim';

/*
update orders set status = 'pending' where orderId = 10182281;
*/


select * from ordersDetail;
DELETE FROM ordersDetail
WHERE username = 'ibrahim';



use userdata;

select * from customer;

select * from book;

select * from cart;

select * from orders;

select * from ordersDetail;