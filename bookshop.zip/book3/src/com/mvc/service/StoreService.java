package com.mvc.service;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Random;
import java.util.UUID;

import com.mvc.bean.CustomerBean;
import com.mvc.bean.OrderBean;
import com.mvc.bean.BookBean;

/* import com.mvc.bean.Employee;
import com.mvc.bean.Transfer;
 */
import com.mvc.dao.CustomerDao;
import com.mvc.dao.PaymentDao;
import com.mvc.dao.BookDao;

public class StoreService {
	
	public static List<CustomerBean> viewCustomer() {
		List<CustomerBean> customerDetails = new ArrayList<>();
		customerDetails = CustomerDao.getCustomerDetails();
		return customerDetails;
	}
	public static List<CustomerBean> viewCustomer1(String username) {
		List<CustomerBean> customerDetails = new ArrayList<>();
		customerDetails = CustomerDao.getCustomerDetails1(username);
		return customerDetails;
	}
	public static CustomerBean viewCustomer2(String username) {
		CustomerBean customerDetails = new CustomerBean();
		customerDetails = CustomerDao.getCustomerDetails2(username);
		return customerDetails;
	}
	public static List<BookBean> viewBook() {
		List<BookBean> BookDetails = new ArrayList<>();
		try {
			BookDetails = BookDao.getBookDetails();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return BookDetails;
	}
	public static List<BookBean> viewBook2(String search) {
		List<BookBean> BookDetails = new ArrayList<>();
		try {
			BookDetails = BookDao.getBookDetails3(search);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return BookDetails;
	}
	public static List<BookBean> getBook(String isbn) {
		List<BookBean> BookDetails = new ArrayList<>();
		try {
			BookDetails = BookDao.getBookDetail(isbn);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return BookDetails;
	}
	public static List<BookBean> getBookCart(String username) {
		List<BookBean> BookDetails = new ArrayList<>();
		try {
			BookDetails = BookDao.getBookDetailCart(username);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return BookDetails;
	}
	public static List<OrderBean> getAllOrder(String username) {
		List<OrderBean> BookDetails = new ArrayList<>();
		
			try {
				BookDetails = PaymentDao.getAllOrderDetails();
			} catch (ClassNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		
		return BookDetails;
	}

	public static List<OrderBean> viewOrder() {
		List<OrderBean> orderDetails = new ArrayList<>();
		try {
			orderDetails = PaymentDao.getAllOrderDetails();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return orderDetails;
	}
	
	public static List<OrderBean> getHistory(String username) {
		List<OrderBean> orderDetails = new ArrayList<>();
		try {
			orderDetails = PaymentDao.getHistoryData(username);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return orderDetails;
	}

}
