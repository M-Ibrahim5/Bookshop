package com.mvc.controller;

import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.mvc.bean.CustomerBean;
import com.mvc.dao.CustomerDao;


@WebServlet("/CustomerEditServlet2")
public class CustomerEditServlet2 extends HttpServlet {
	private static final long serialVersionUID = 1L;
	List<CustomerBean> customerDetails = new ArrayList<>();
	
    public CustomerEditServlet2() {
        super();
    }

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String username1 = request.getParameter("username1");
		String password1 = request.getParameter("password1");
		String username = request.getParameter("username");
        String email = request.getParameter("email");
        String address = request.getParameter("address");
        String phone = request.getParameter("phone");
        String password = request.getParameter("password");
        String age = request.getParameter("age");
		
		CustomerBean customer = new CustomerBean();
		customer.setUserName(username);
		customer.setEmail(email);
		customer.setAddress(address);
		customer.setPhone(phone);
		customer.setpassword(password);
		customer.setAge(age);

		CustomerDao customerDao =new CustomerDao();

			Boolean updated;
			try {
				updated = customerDao.editCustomerDetails(customer);
			
			if(updated==true) {
				request.setAttribute("username1", username1); 
				request.setAttribute("password1", password1);
				RequestDispatcher dispatcher = request.getServletContext().getRequestDispatcher("/AccountServlet");
				dispatcher.forward(request, response);
				
			}else {
				request.setAttribute("username1", username1); 
				request.setAttribute("password1", password1);
				request.setAttribute("errMessage", "Update failed !");
				RequestDispatcher dispatcher = request.getServletContext().getRequestDispatcher("/failure.jsp");
				dispatcher.forward(request, response);
			}
			} catch (ClassNotFoundException | SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}


		
	}
}


