package com.mvc.controller;
import java.io.IOException;
import java.util.List;
import java.util.*;


import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.annotation.WebServlet;
import com.mvc.bean.BookBean;
import com.mvc.dao.BookDao;
import com.mvc.service.StoreService;

@WebServlet("/AddToCartBridgeServlet")

public class AddToCartBridgeServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	List<BookBean> BookDetails = new ArrayList<>();

	private BookDao BookDAO;

    public AddToCartBridgeServlet() {

    }
	public void init() {
		BookDAO = new BookDao(); 
	}


	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		String username1 = request.getParameter("username1");
		String password1 = request.getParameter("password1");
		String isbn = request.getParameter("isbn");
		BookDetails = StoreService.getBook(isbn);
		String price = request.getParameter("price");

		if(BookDetails==null)
		{
			request.setAttribute("username1", username1); 
			request.setAttribute("password1", password1);
			response.sendRedirect("failure.jsp");
		}
		else
		{
			request.setAttribute("username1", username1); 
			request.setAttribute("password1", password1);
			request.setAttribute("BookDetails", BookDetails);
			request.setAttribute("isbn", isbn);
			request.setAttribute("price", price);
			
			RequestDispatcher rd = request.getRequestDispatcher("Cart.jsp");
			
			rd.forward(request, response);
			
		}
	}
}
