package com.mvc.controller;

import java.io.IOException;
import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Random;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.annotation.WebServlet;
import java.time.LocalDate;


import org.apache.commons.fileupload.FileItem;
import org.apache.commons.fileupload.FileItemFactory;
import org.apache.commons.fileupload.disk.DiskFileItemFactory;
import org.apache.commons.fileupload.servlet.ServletFileUpload;
import org.apache.commons.io.FilenameUtils;

import com.mvc.bean.BookBean;
import com.mvc.bean.OrderBean;
import com.mvc.bean.OrderDetailBean;
import com.mvc.dao.BookDao;
import com.mvc.dao.PaymentDao;
import com.mvc.service.StoreService;

@WebServlet("/CheckoutServlet")
public class CheckoutServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private PaymentDao PaymentDao;  
	List<BookBean> BookDetails3 = new ArrayList<>();

	
    public CheckoutServlet() {

    }
	public void init() {
		PaymentDao = new PaymentDao(); 
	}

	public void doGet(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException {
        doPost(request, response);
    }
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	
		String fullName1 = request.getParameter("fullName");
		String email = request.getParameter("email");
		String address = request.getParameter("address");
		String price   = request.getParameter("price");
		String phone = request.getParameter("phone");
		String payment   = request.getParameter("payment");
		String cardId  = request.getParameter("cardId");
		String total  = request.getParameter("total");
		if (cardId.equals(null)) {
			cardId = "null";
		}
		
		String username1 = request.getParameter("username1");
		String password1 = request.getParameter("password1");
		
		
		Random random = new Random();
        int orderId1 = 10000000 + random.nextInt(1000000);
		int payId1 = 100000 + random.nextInt(10000);
		
		String orderId = Integer.toString(orderId1);
		String payId = Integer.toString(payId1);
		
		
        String isbn22 = null;
		List<BookBean> BookDetails4 = new ArrayList<>();
		BookDetails4 = BookDao.getIsbnCart(username1);
		if(BookDetails4!=null){
			for (var isbnn : BookDetails4) {
				if(isbn22 != null){
					isbn22 += ","+isbnn.getIsbn(); 
				}else{
					isbn22=isbnn.getIsbn();
				}
				
			}
		}else{
			System.out.println("BookDetails4 is null");
		}
		
		

		String date = null;
		
		String status = "pending";  
		OrderBean neworder = new OrderBean(orderId, payId, username1, isbn22, date, total, status);
		
		List<BookBean> BookDetails7 = new ArrayList<>();

		//orderDetailId, orderId, username, fullname, isbn, quantity, email, address, phone, linePrice, payType, cardId
		BookDetails7 = BookDao.getBookDetailCart(username1);
		
		String fullName = fullName1;
		System.out.println(fullName);
		
		String addorder = PaymentDao.addOrder(neworder);

		if(addorder.equals("SUCCESS"))   //On success, you can display a message to user on Home page
		{
			String addorderdetail = null;
			for (BookBean book : BookDetails7) {
				float linePrice1 = BookDao.getLinePrice(book.getQuantity(),book.getPrice());
				String linePrice = Float.toString(linePrice1);
				int orderDetailId1 = 10000 + random.nextInt(1000);
				String orderDetailId = Integer.toString(orderDetailId1);
				OrderDetailBean newOrderDetail = new OrderDetailBean(orderDetailId, orderId, username1, fullName, book.getIsbn(), book.getQuantity(), email, address, phone, linePrice, payment, cardId);
				addorderdetail = PaymentDao.addOrderDetail(newOrderDetail);
			}
			BookDetails3 = StoreService.getBookCart(username1);
		System.out.println(BookDetails3);
			try {
				PaymentDao.deleteCart(username1);
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
		}

		
		if(BookDetails3==null)
		{
			request.setAttribute("username1", username1); 
			request.setAttribute("password1", password1);
			response.sendRedirect("failure.jsp");
		}
		else
		{
			request.setAttribute("username1", username1); 
			request.setAttribute("password1", password1);
			request.setAttribute("fullName", fullName);
			request.setAttribute("address", address);
			request.setAttribute("email", email);
			request.setAttribute("phone", phone);
			request.setAttribute("total", total);
			request.setAttribute("BookDetails3", BookDetails3);	
			request.getRequestDispatcher("/Invoice.jsp").forward(request, response);
		}
		}
		else   //On Failure, display a meaningful message to the User.
		{
			request.setAttribute("username1", username1); 
			request.setAttribute("password1", password1);
			request.setAttribute("errMessage", addorder);
			request.getRequestDispatcher("/failure.jsp").forward(request, response);
		}
 
	}
}
