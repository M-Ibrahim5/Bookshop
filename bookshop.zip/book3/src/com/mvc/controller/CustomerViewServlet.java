package com.mvc.controller;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.mvc.bean.CustomerBean;
import com.mvc.service.StoreService;


@WebServlet("/CustomerViewServlet")
public class CustomerViewServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	List<CustomerBean> customerDetails = new ArrayList<>();
	

    public CustomerViewServlet() {
        super();
    }

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	String username1 = request.getParameter("username1");
	String password1 = request.getParameter("password1");
	

	customerDetails = StoreService.viewCustomer();
		
		if(customerDetails==null)
		{
			request.setAttribute("username1", username1); 
			request.setAttribute("password1", password1);
			response.sendRedirect("failure.jsp");
		}
		else
		{
			request.setAttribute("username1", username1); 
			request.setAttribute("password1", password1);
			request.setAttribute("customerDetails", customerDetails);	
			
			RequestDispatcher rd = request.getRequestDispatcher("Customer2.jsp");
			
			rd.forward(request, response);
			
		}
	}

}
