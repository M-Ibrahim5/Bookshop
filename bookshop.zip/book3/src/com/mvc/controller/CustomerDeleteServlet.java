package com.mvc.controller;
import java.io.IOException;
import java.sql.SQLException;
import javax.servlet.RequestDispatcher;
import javax.servlet.Servlet;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.annotation.WebServlet;

import com.mvc.dao.CustomerDao;

@WebServlet("/CustomerDeleteServlet")
public class CustomerDeleteServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    private CustomerDao CustomerDAO;

	/**
	 * @see Servlet#init(ServletConfig)
	 */
	public void init() {
		CustomerDAO = new CustomerDao(); 
	}
	

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		String value0 = request.getParameter("id");
		String username1 = request.getParameter("username1");
		String password1 = request.getParameter("password1");
		
		try {
			CustomerDAO.deleteCustomer(value0);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		request.setAttribute("username1", username1); 
		request.setAttribute("password1", password1);
		RequestDispatcher dispatcher = request.getRequestDispatcher("/CustomerViewServlet");
		dispatcher.forward(request, response);

		}

	

}