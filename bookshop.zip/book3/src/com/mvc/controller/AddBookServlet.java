package com.mvc.controller;

import java.io.IOException;
import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Iterator;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.annotation.WebServlet;

import org.apache.commons.fileupload.FileItem;
import org.apache.commons.fileupload.FileItemFactory;
import org.apache.commons.fileupload.disk.DiskFileItemFactory;
import org.apache.commons.fileupload.servlet.ServletFileUpload;
import org.apache.commons.io.FilenameUtils;

import com.mvc.bean.BookBean;
import com.mvc.dao.BookDao;

@WebServlet("/AddBookServlet")
public class AddBookServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private BookDao BookDao;  

	
    public AddBookServlet() {

    }
	public void init() {
		BookDao = new BookDao(); 
	}

	public void doGet(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException {
        doPost(request, response);
    }
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	
		String isbn = request.getParameter("isbn");
		String title = request.getParameter("title");
		String author =  request.getParameter("author");
		String publisher = request.getParameter("publisher");
		String price   = request.getParameter("price");
		String keyword = request.getParameter("keyword");
		String category   = request.getParameter("category");
		String description  = request.getParameter("description");
		String stock    = request.getParameter("stock");
		String image = request.getParameter("image");
		
		String username1 = request.getParameter("username1");
		String password1 = request.getParameter("password1");
		
		//String userType = request.getParameter("usertype");
		
		BookBean newBook = new BookBean(isbn, title, author, publisher, price, keyword, category, description, stock, image+".jpeg");
		
		String addbook = BookDao.addBook(newBook);

		if(addbook.equals("SUCCESS"))   //On success, you can display a message to user on Home page
		{
			request.setAttribute("username1", username1); 
			request.setAttribute("password1", password1);
			request.getRequestDispatcher("/Home.jsp").forward(request, response);
		}
		else   //On Failure, display a meaningful message to the User.
		{
			request.setAttribute("username1", username1); 
			request.setAttribute("password1", password1);
			request.setAttribute("errMessage", addbook);
			request.getRequestDispatcher("/failure.jsp").forward(request, response);
		}



	}
}
