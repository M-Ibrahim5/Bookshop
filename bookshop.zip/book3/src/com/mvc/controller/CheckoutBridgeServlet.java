package com.mvc.controller;
import java.io.IOException;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/CheckoutBridgeServlet")
public class CheckoutBridgeServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       

    public CheckoutBridgeServlet() {
    }

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String username1 = request.getParameter("username1");
		String password1 = request.getParameter("password1");
		String total = request.getParameter("total");
		request.setAttribute("total", total); 
		request.setAttribute("username1", username1); 
		request.setAttribute("password1", password1);
		 
        RequestDispatcher dispatcher = request.getServletContext().getRequestDispatcher("/CheckoutForm.jsp");
        dispatcher.forward(request, response);
	}

}
