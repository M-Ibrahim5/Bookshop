package com.mvc.controller;

import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.mvc.bean.BookBean;
import com.mvc.dao.BookDao;


@WebServlet("/BookEditServlet")
public class BookEditServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	List<BookBean> bookDetails = new ArrayList<>();

    public BookEditServlet() {
        super();
    }

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String username1 = request.getParameter("username1");
		String password1 = request.getParameter("password1");
		
		String isbn = request.getParameter("isbn");
		String title = request.getParameter("title");
		String author =  request.getParameter("author");
		String publisher = request.getParameter("publisher");
		String price   = request.getParameter("price");
		String keyword = request.getParameter("keyword");
		String category   = request.getParameter("category");
		String description  = request.getParameter("description");
		String stock    = request.getParameter("stock");
		String image = request.getParameter("image");
		
		BookBean book = new BookBean();

		book.setIsbn(isbn);
		book.setTitle(title);
		book.setAuthor(author);
		book.setPublisher(publisher);
		book.setPrice(price);
		book.setKeyword(keyword);
		book.setCategory(category);
		book.setDescription(description);
		book.setStock(stock);
		book.setImage(image);

		BookDao BookDao =new BookDao();

			Boolean updated;
			try {
				updated = BookDao.editbookDetails(book);
			
			if(updated==true) {
				request.setAttribute("isbn", isbn); 
				request.setAttribute("username1", username1); 
				request.setAttribute("password1", password1);
				RequestDispatcher dispatcher = request.getServletContext().getRequestDispatcher("/bookViewServlet");
				dispatcher.forward(request, response);
				
			}else {
				request.setAttribute("isbn", isbn); 
				request.setAttribute("username1", username1); 
				request.setAttribute("password1", password1);
				request.setAttribute("errMessage", "Update failed !");
				RequestDispatcher dispatcher = request.getServletContext().getRequestDispatcher("/EditBookBridgeServlet");
				dispatcher.forward(request, response);
			}
			} catch (ClassNotFoundException | SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}


		
	}
}


