package com.mvc.controller;

import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.mvc.bean.BookBean;
import com.mvc.bean.OrderBean;
import com.mvc.dao.BookDao;
import com.mvc.dao.PaymentDao;
import com.mvc.service.StoreService;

import javax.servlet.annotation.WebServlet;
@WebServlet("/OrderServlet")
public class OrderServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	List<OrderBean> orderDetails = new ArrayList<>();
	float income=0;

    public OrderServlet() {
        super();
    }

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		String username1 = request.getParameter("username1");
		String password1 = request.getParameter("password1");
		orderDetails = StoreService.viewOrder();
		try {
			income = PaymentDao.getIncome();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		if(orderDetails==null)
		{
			request.setAttribute("username1", username1); 
			request.setAttribute("password1", password1);
			response.sendRedirect("failure.jsp");
		}
		else
		{
			request.setAttribute("username1", username1); 
			request.setAttribute("password1", password1);
			request.setAttribute("orderDetails", orderDetails);	
			request.setAttribute("income", income);	
			
			RequestDispatcher rd = request.getRequestDispatcher("ViewOrder.jsp");
			
			rd.forward(request, response);
			
		}
	}

}
