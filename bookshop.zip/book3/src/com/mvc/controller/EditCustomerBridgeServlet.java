package com.mvc.controller;
import java.io.IOException;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/EditCustomerBridgeServlet")
public class EditCustomerBridgeServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       

    public EditCustomerBridgeServlet() {
    }


	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String id = request.getParameter("id");
		request.setAttribute("id", id);
		String username1 = request.getParameter("username1");
		String password1 = request.getParameter("password1");
		request.setAttribute("username1", username1); 
		request.setAttribute("password1", password1);
		 

        RequestDispatcher dispatcher = request.getServletContext().getRequestDispatcher("/CustomerEditForm.jsp");
        dispatcher.forward(request, response);
	}

}
