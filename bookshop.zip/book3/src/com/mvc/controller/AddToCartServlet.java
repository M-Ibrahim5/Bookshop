package com.mvc.controller;
import java.io.IOException;
import java.util.List;
import java.util.*;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.annotation.WebServlet;
import com.mvc.bean.BookBean;
import com.mvc.dao.BookDao;
import com.mvc.service.StoreService;

@WebServlet("/AddToCartServlet")

public class AddToCartServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	List<BookBean> BookDetails = new ArrayList<>();

	private BookDao BookDAO;

    public AddToCartServlet() {

    }
	public void init() {
		BookDAO = new BookDao(); 
	}


	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		String username1 = request.getParameter("username1");
		String password1 = request.getParameter("password1");
		String isbn = request.getParameter("isbn");
		String quantity2 = request.getParameter("quantity");
		String price = request.getParameter("price");
		//int quantity = Integer.parseInt(quantity2);
		String addcart = BookDao.addCart(username1,isbn,quantity2,price);

		if(addcart.equals("SUCCESS"))   //On success, you can display a message to user on Home page
		{
			request.setAttribute("username1", username1); 
			request.setAttribute("password1", password1);
			request.getRequestDispatcher("/BookViewCustomerServlet").forward(request, response);
		}
		else   //On Failure, display a meaningful message to the User.
		{
			request.setAttribute("username1", username1); 
			request.setAttribute("password1", password1);
			request.setAttribute("errMessage", addcart);
			request.getRequestDispatcher("/failure.jsp").forward(request, response);
		}
	}
}
