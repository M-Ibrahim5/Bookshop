package com.mvc.controller;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.mvc.bean.BookBean;
import com.mvc.service.StoreService;

import javax.servlet.annotation.WebServlet;
@WebServlet("/SearchServlet")
public class SearchServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	List<BookBean> BookDetails2 = new ArrayList<>();
	
    public SearchServlet() {
        super();
    }

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		String username1 = request.getParameter("username1");
		String password1 = request.getParameter("password1");
		String search = request.getParameter("search");
		BookDetails2 = StoreService.viewBook2(search);
		
		if(BookDetails2==null)
		{
			request.setAttribute("username1", username1); 
			request.setAttribute("password1", password1);
			response.sendRedirect("failure.jsp");
		}
		else
		{
			request.setAttribute("username1", username1); 
			request.setAttribute("password1", password1);
			request.setAttribute("BookDetails2", BookDetails2);	
			
			RequestDispatcher rd = request.getRequestDispatcher("DisplayImageCustomer2.jsp");
			
			rd.forward(request, response);
			
		}
	}

}
