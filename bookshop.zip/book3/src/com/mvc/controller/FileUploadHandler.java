package com.mvc.controller;
import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Iterator;
import java.util.List;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.apache.commons.fileupload.FileItem;
import org.apache.commons.fileupload.FileItemFactory;
import org.apache.commons.fileupload.disk.DiskFileItemFactory;
import org.apache.commons.fileupload.servlet.ServletFileUpload;
import org.apache.commons.io.FilenameUtils;
import javax.servlet.annotation.WebServlet;


@WebServlet("/FileUploadHandler")
public class FileUploadHandler extends HttpServlet {
    private static final long serialVersionUID = 1 ;
    public void doGet(HttpServletRequest request, HttpServletResponse response) throws IOException {
        doPost(request, response);
    }
    public void doPost(HttpServletRequest request, HttpServletResponse response) throws IOException {
        String username1 = request.getParameter("username1");
        String password1 = request.getParameter("password1");
        request.setAttribute("username1", username1); 
        request.setAttribute("password1", password1);
                
        String file_name = null;
        String path1 = "C://Users//Acer//Desktop//code//coding//eclipse//book3//WebContent//Images//up//";
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();
        boolean isMultipartContent = ServletFileUpload.isMultipartContent(request);
        if (!isMultipartContent) {
            return;
        }
        FileItemFactory factory = new DiskFileItemFactory();
        ServletFileUpload upload = new ServletFileUpload(factory);
        String filepathh = null;
        try {
            List < FileItem > fields = upload.parseRequest(request);
            Iterator < FileItem > it = fields.iterator();
            if (!it.hasNext()) {
                return;
            }
            while (it.hasNext()) {
                FileItem fileItem = it.next();
                boolean isFormField = fileItem.isFormField();
                if (isFormField) {
                    if (file_name == null) {
                        if (fileItem.getFieldName().equals("file_name")) {
                        	file_name = fileItem.getString();
                        }
                    }
                } else {
                    if (fileItem.getSize() > 0) {
                        fileItem.write(new File("C://Users//Acer//Desktop//code//coding//eclipse//book3//WebContent//Images//" + fileItem.getName()));
                        filepathh = FilenameUtils.getBaseName(fileItem.getName());
                     }
                }
            }
            
        } catch (Exception e) {
            e.printStackTrace();
        
        } finally {
            
            out.println("<script type='text/javascript'>");
            //out.println("window.location.href='index.jsp?filename="+file_name+", pathh = "+filepathh);
            out.println("window.location.href='AddBookForm.jsp?filename="+filepathh+"'");
            out.println("</script>");
            out.close();
        }

    }
}