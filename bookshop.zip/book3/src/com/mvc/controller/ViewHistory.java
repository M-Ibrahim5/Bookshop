package com.mvc.controller;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.mvc.bean.OrderBean;
import com.mvc.dao.PaymentDao;
import com.mvc.service.StoreService;

import javax.servlet.annotation.WebServlet;
@WebServlet("/ViewHistory")
public class ViewHistory extends HttpServlet {
	private static final long serialVersionUID = 1L;
	List<OrderBean> order = new ArrayList<>();
	
    public ViewHistory() {
        super();
    }

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		String username1 = request.getParameter("username1");
		String password1 = request.getParameter("password1");
		order = StoreService.getHistory(username1);
		//float total = BookDao.getTotal(username1);

		if(order==null)
		{
			request.setAttribute("username1", username1); 
			request.setAttribute("password1", password1);
			response.sendRedirect("failure.jsp");
		}
		else
		{
			request.setAttribute("username1", username1); 
			request.setAttribute("password1", password1);
			//request.setAttribute("total", total);
			request.setAttribute("order", order);	
			
			RequestDispatcher rd = request.getRequestDispatcher("ViewHistory.jsp");
			
			rd.forward(request, response);
			
		}
	}

}
