package com.mvc.controller;
import java.io.IOException;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/EditBookBridgeServlet")
public class EditBookBridgeServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       

    public EditBookBridgeServlet() {
    }


	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String isbn = request.getParameter("isbn");
		request.setAttribute("isbn", isbn);
		String username1 = request.getParameter("username1");
		String password1 = request.getParameter("password1");
		request.setAttribute("username1", username1); 
		request.setAttribute("password1", password1);
		 

        RequestDispatcher dispatcher = request.getServletContext().getRequestDispatcher("/BookEditForm.jsp");
        dispatcher.forward(request, response);
	}

}
