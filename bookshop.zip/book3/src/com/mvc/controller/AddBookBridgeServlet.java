package com.mvc.controller;
import java.io.IOException;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.annotation.WebServlet;


@WebServlet("/AddBookBridgeServlet")

public class AddBookBridgeServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

    public AddBookBridgeServlet() {

    }


	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		String username1 = request.getParameter("username1");
		String password1 = request.getParameter("password1");
		request.setAttribute("username1", username1); 
		request.setAttribute("password1", password1);
		RequestDispatcher dispatcher = request.getServletContext().getRequestDispatcher("/AddBookForm.jsp");
		dispatcher.forward(request, response);

	}
}
