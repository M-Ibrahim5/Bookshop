package com.mvc.controller;
import java.io.IOException;
import java.sql.SQLException;
import javax.servlet.RequestDispatcher;
import javax.servlet.Servlet;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.annotation.WebServlet;

import com.mvc.dao.BookDao;

@WebServlet("/CartDeleteServlet")
public class CartDeleteServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    private BookDao BookDAO;

	/**
	 * @see Servlet#init(ServletConfig)
	 */
	public void init() {
		BookDAO = new BookDao(); 
	}
	

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		String value0 = request.getParameter("isbn");
		String username1 = request.getParameter("username1");
		String password1 = request.getParameter("password1");
		String quantity = request.getParameter("quantity");
		
		try {
			BookDAO.deleteCart(value0,username1,quantity);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		request.setAttribute("username1", username1); 
		request.setAttribute("password1", password1);
		RequestDispatcher dispatcher = request.getRequestDispatcher("/ViewCartServlet");
		dispatcher.forward(request, response);

		}

	

}