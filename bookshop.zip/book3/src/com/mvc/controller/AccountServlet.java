package com.mvc.controller;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.mvc.bean.CustomerBean;
import com.mvc.service.StoreService;


@WebServlet("/AccountServlet")
public class AccountServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	CustomerBean customerDetails = new CustomerBean();
	

    public AccountServlet() {
        super();
    }

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	String username1 = request.getParameter("username1");
	String password1 = request.getParameter("password1");
	

	//customerDetails = StoreService.viewCustomer2(username1);

		if(customerDetails==null)
		{
			request.setAttribute("username1", username1); 
			request.setAttribute("password1", password1);
			response.sendRedirect("failure.jsp");
		}
		else
		{
			request.setAttribute("username1", username1); 
			request.setAttribute("password1", password1);
			//request.setAttribute("customerDetails", customerDetails);	
			
			RequestDispatcher rd = request.getRequestDispatcher("Account2.jsp");
			
			rd.forward(request, response);
			
		}
	}

}
