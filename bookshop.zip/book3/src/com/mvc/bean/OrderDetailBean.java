package com.mvc.bean;

public class OrderDetailBean {

    
    private String fullName;
    private String email;
    private String address;
    private String linePrice;
    private String phone;
    private String payType;
    private String cardId;
    private String orderDetailId;
    private String isbn;
    private String quantity ;
    private String orderId;
    private String username;

    public OrderDetailBean(){

    }
    public OrderDetailBean(String orderDetailId,String orderId, String username, String fullName, String isbn, String quantity, String email, String address, String phone, String linePrice, String payType, String cardId) {
    	this.orderDetailId=orderDetailId;
    	this.orderId=orderId;
    	this.username=username;
    	this.fullName=fullName;
    	this.isbn=isbn;
    	this.quantity=quantity;
    	this.email=email;
    	this.address=address;
    	this.phone=phone;
    	this.linePrice=linePrice;
    	this.payType=payType;
    	this.cardId=cardId;
    	
    }
    public String getFullName() {
        return fullName;
    }
    public void setFullName(String fullName) {
        this.fullName = fullName;
    }
    public String getEmail() {
        return email;
    }
    public void setEmail(String email) {
        this.email = email;
    }
    public String getPhone() {
        return phone;
    }
    public void setPhone(String phone) {
        this.phone = phone;
    }
    public String getAddress() {
        return address;
    }
    public void setAddress(String address) {
        this.address = address;
    }
    public String getPayType() {
        return payType;
    }
    public void setPayType(String payType) {
        this.payType = payType;
    }
    public String getCardId() {
        return cardId;
    }
    public void setCardId(String cardId) {
        this.cardId = cardId;
    }
    
    public String getOrderDetailId() {
        return orderDetailId;
    }
    public void setOrderDetailId(String orderDetailId) {
        this.orderDetailId = orderDetailId;
    }
    public String getLinePrice() {
        return linePrice;
    }
    public void setLinePrice(String linePrice) {
        this.linePrice = linePrice;
    }
    public String getOrderId() {
        return orderId;
    }
    public void setOrderId(String orderId) {
        this.orderId = orderId;
    }
    public String getUsername() {
        return username;
    }
    public void setUsername(String username) {
        this.username = username;
    }
    public String getIsbn() {
        return isbn;
    }
    public void setIsbn(String isbn) {
        this.isbn = isbn;
    }
    public String getQuantity() {
        return quantity;
    }
    public void setQuantity(String quantity) {
        this.quantity = quantity;
    }
    
}
