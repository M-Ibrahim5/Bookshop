package com.mvc.bean;
 
public class RegisterBean {
 
 private String email;
 private String userName;
 private String password;
 private String phone;
 private String address;
 private String age;


 public String getUserName() {
 return userName;
 }
 public void setUserName(String userName) {
 this.userName = userName;
 }
 public String getAge() {
 return age;
 }
 public void setAge(String age) {
 this.age = age;
 }
 public String getPassword() {
 return password;
 }
 public void setPassword(String password) {
 this.password = password;
 }
 public void setEmail(String email) {
 this.email = email;
 }
 public String getEmail() {
 return email;
 }
 public void setPhone(String phone) {
 this.phone = phone;
 }
 public String getPhone() {
 return phone;
 }
 public void setAddress(String address) {
 this.address = address;
 }
 public String getAddress() {
 return address;
 }
}