package com.mvc.bean;

public class BookBean {
    private String isbn;
    private String title;
    private String author;
    private String publisher;
    private String price;
    private String keyword;
    private String category;
    private String description;
    private String stock;
    private String image;
    private String base64Image;
    private String quantity;
 
 
    

    public BookBean(){
        
    }
    public BookBean(String isbn){
        this.isbn = isbn;
    }
    public BookBean(String isbn, String title, String author, String publisher, String price, String keyword, String category, String description, String stock,String image){
        this.isbn = isbn;
        this.title = title;
        this.author = author;
        this.publisher = publisher;
        this.price = price;
        this.keyword = keyword;
        this.category = category;
        this.description = description;
        this.stock = stock;
        this.image = image;
    }

    public BookBean(String isbn, String title, String price){
        this.isbn = isbn;
        this.title = title;
        this.price = price;
    }
    public BookBean(String isbn, String title, String price, String quantity){
        this.isbn = isbn;
        this.title = title;
        this.price = price;
        this.quantity = quantity;

    }

    public String getIsbn() {
        return isbn;
    }
     public void setIsbn(String isbn) {
        this.isbn = isbn;
    }
    public String getTitle() {
        return title;
    }
     public void setTitle(String title) {
        this.title = title;
    }
    public String getAuthor() {
        return author;
    }
     public void setAuthor(String author) {
        this.author = author;
    }
    public String getPublisher() {
        return publisher;
    }
     public void setPublisher(String publisher) {
        this.publisher = publisher;
    }
    public String getPrice() {
        return price;
    }
     public void setPrice(String price) {
        this.price = price;
    }
    public String getKeyword() {
        return keyword;
    }
     public void setKeyword(String keyword) {
        this.keyword = keyword;
    }
    public String getCategory() {
        return category;
    }
     public void setCategory(String category) {
        this.category = category;
    }
    public String getDescription() {
        return description;
    }
     public void setDescription(String description) {
        this.description = description;
    }
    public String getStock() {
        return stock;
    }
     public void setStock(String stock) {
        this.stock = stock;
    }
    public String getImage() {
        return image;
    }
     public void setImage(String image) {
        this.image = image;
    }
    public String getQuantity() {
        return quantity;
    }
     public void setQuantity(String quantity) {
        this.quantity = quantity;
    }
    
}
