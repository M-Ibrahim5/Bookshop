package com.mvc.bean;

public class PaymentBean {
    private String isbn;
    private String payid;
    private String id;
    private String paytype;
    private String totprice;
    private String date;
    private String quantity;

    public String getIsbn() {
        return isbn;
    }
    public void setIsbn(String isbn) {
        this.isbn = isbn;
    }
    public String getPayid() {
        return payid;
    }
    public void setPayid(String payid) {
        this.payid = payid;
    }
    public String getId() {
        return id;
    }
    public void setId(String id) {
        this.id = id;
    }
    public String getPaytype() {
        return paytype;
    }
    public void setPaytype(String paytype) {
        this.paytype = paytype;
    }
    public String getTotprice() {
        return totprice;
    }
    public void setTotprice(String totprice) {
        this.totprice = totprice;
    }
    public String getDate() {
        return date;
    }
    public void setDate(String date) {
        this.date = date;
    }
    public String getQuantity() {
        return quantity;
    }
    public void setQuantity(String quantity) {
        this.quantity = quantity;
    }
}
