package com.mvc.bean;

public class OrderBean {
    
    private String orderDetailId;
    private String isbn;
    private String quantity ;
    private String orderId;
    private String payId;
    private String username;
    private String date;
    private String total;
    private String status;

    public OrderBean(){

    }

    public OrderBean(String orderId,String  payId,String  username,String  isbn,String  date,String  total,String  status){
        this.orderId=orderId;
        this.payId=payId;
        this.username=username;
        this.isbn=isbn;
        this.date=date;
        this.total=total;
        this.status=status;
    }   

    
    
    public String getOrderDetailId() {
        return orderDetailId;
    }
    public void setOrderDetailId(String orderDetailId) {
        this.orderDetailId = orderDetailId;
    }
    
    public String getOrderId() {
        return orderId;
    }
    public void setOrderId(String orderId) {
        this.orderId = orderId;
    }
    public String getPayId() {
        return payId;
    }
    public void setPayId(String payId) {
        this.payId = payId;
    }
    public String getUsername() {
        return username;
    }
    public void setUsername(String username) {
        this.username = username;
    }
    public String getDate() {
        return date;
    }
    public void setDate(String date) {
        this.date = date;
    }
    public String getTotal() {
        return total;
    }
    public void setTotal(String total) {
        this.total = total;
    }
    public String getStatus() {
        return status;
    }
    public void setStatus(String status) {
        this.status = status;
    }
    public String getIsbn() {
        return isbn;
    }
    public void setIsbn(String isbn) {
        this.isbn = isbn;
    }
}
