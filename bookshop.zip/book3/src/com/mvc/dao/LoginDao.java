package com.mvc.dao;
 
import java.sql.*;
import com.mvc.bean.LoginBean;
import com.mvc.util.DBConnection;
 
public class LoginDao {
     public String authenticateUser(LoginBean loginBean)
     {
         String username1 = loginBean.getUserName(); //Assign user entered values to temporary variables.
         String password1 = loginBean.getPassword();
 
         Connection con = null;
         Statement statement = null;
         ResultSet resultSet = null;
 
         String userNameDB = "";
         String passwordDB = "";
        
         try
         {
             con = DBConnection.createConnection(); //Fetch database connection object
             statement = con.createStatement(); //Statement is used to write queries. Read more about it.
             resultSet = statement.executeQuery("SELECT username,password from customer"); //the table name is users and userName,password are columns. Fetching all the records and storing in a resultSet.
 
             while(resultSet.next()) // Until next row is present otherwise it return false
             {
              userNameDB = resultSet.getString("username"); //fetch the values present in database
              passwordDB = resultSet.getString("password");
               if(username1.equals("admin") && password1.equals("abc123")) {
            	   return "ADMIN";
               }
                else if(username1.equals(userNameDB) && password1.equals(passwordDB))
               {
                  return "SUCCESS"; ////If the user entered values are already present in the database, which means user has already registered so return a SUCCESS message.
               }
             }
          }catch(SQLException e) {
             
                e.printStackTrace();
          }
             return "Invalid user"; // Return appropriate message in case of failure
         }
     }
