package com.mvc.dao;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.sql.*;
import java.util.ArrayList;
import java.util.Base64;
import java.util.List;

import javax.sql.DataSource;

import com.mvc.bean.BookBean;
import com.mvc.bean.OrderBean;
import com.mvc.bean.OrderDetailBean;
import com.mvc.util.DBConnection;

public class PaymentDao{
	
	private static final String GET_BOOK = "SELECT title, price FROM book where isbn=?"; //orderId, payId, username, date, total, status, isbn
	private static final String ADD_ORDER_SQL = "INSERT INTO orders (orderId, payId, username, date, total, status, isbn) VALUES (?,?,?,CURDATE(),?,?,?)";
	private static final String ADD_ORDER_DETAIL_SQL = "INSERT INTO ordersDetail (orderDetailId, orderId, username, fullname, isbn, quantity, email, address, phone, linePrice, payType, cardId) VALUES (?,?,?,?,?,?,?,?,?,?,?,?)";
	private static final String GET_ORDER = "SELECT * FROM orders";
	private static final String GET_HISTORY = "SELECT * FROM orders WHERE username = ?";
	private static final String COMPLETE_ORDER = "update orders set status = ? where orderId = ?";
	private static final String DELETE_CART = "delete from cart where username =?";

	public static final String url="jdbc:mysql://localhost:3306/userdata";
	public static final String username="root";
	public static final String password="satulapan#123";

    private Connection connection;

    static Connection con = null;
	
	public PaymentDao() {
		
	}
    
	//-------------------------------------------------------------------------

    

	//ADD order       orderId, payId, username, isbn, date, total, status
	public static String addOrder(OrderBean order){
		System.out.println(ADD_ORDER_SQL);
		try (Connection con = DBConnection.createConnection();
			PreparedStatement preparedStatement = con.prepareStatement(ADD_ORDER_SQL)) {
			preparedStatement.setString(1, order.getOrderId());
			preparedStatement.setString(2, order.getPayId());
			preparedStatement.setString(3, order.getUsername());
			preparedStatement.setString(4, order.getTotal());
			preparedStatement.setString(5, order.getStatus());
			preparedStatement.setString(6,order.getIsbn());
			//orderId, payId, username, date, total, status, isbn
			System.out.println(preparedStatement);
			int i= preparedStatement.executeUpdate();
			
			if (i!=0)  //Just to ensure data has been inserted into the database
			return "SUCCESS"; 
			
		}catch (SQLException e) {
			e.printStackTrace();
		}
		return "Oops.. Something went wrong there..!";
	}

	
	public static String addOrderDetail(OrderDetailBean order){
		System.out.println(ADD_ORDER_DETAIL_SQL);
		try (Connection con = DBConnection.createConnection();
			PreparedStatement preparedStatement = con.prepareStatement(ADD_ORDER_DETAIL_SQL)) {
			preparedStatement.setString(1, order.getOrderDetailId());
			preparedStatement.setString(2, order.getOrderId());
			preparedStatement.setString(3, order.getUsername());
			preparedStatement.setString(4, order.getFullName());
			preparedStatement.setString(5, order.getIsbn());
			preparedStatement.setString(6, order.getQuantity());
			preparedStatement.setString(7,order.getEmail());
			preparedStatement.setString(8,order.getAddress());
			preparedStatement.setString(9, order.getPhone());
			preparedStatement.setString(10, order.getLinePrice());
			preparedStatement.setString(11, order.getPayType());
			preparedStatement.setString(12,order.getCardId());
			System.out.println(preparedStatement);
			int i= preparedStatement.executeUpdate();
			
			if (i!=0)  //Just to ensure data has been inserted into the database
			return "SUCCESS"; 
			
		}catch (SQLException e) {
			e.printStackTrace();
		}
		return "Oops.. Something went wrong there..!";
	}

	public static List<OrderBean> getAllOrderDetails() throws ClassNotFoundException{
		List<OrderBean> orderDetails = new ArrayList<>();
			try {
				
				Connection con = DBConnection.createConnection();
				PreparedStatement pstmt = null;
				pstmt = con.prepareStatement(GET_ORDER);
				ResultSet rs = pstmt.executeQuery();
				//orderId, payId, username, date, total, status, isbn
				while (rs.next()) { 
					OrderBean order = new OrderBean(); 
					order.setOrderId(rs.getString(1));
					order.setPayId(rs.getString(2));
					order.setUsername(rs.getString(3));
					order.setDate(rs.getString(4));
					order.setTotal(rs.getString(5));
					order.setStatus(rs.getString(6));
					order.setIsbn(rs.getString(7));
					orderDetails.add(order);

				}
			} catch (SQLException e) {
				System.out.println(e.getMessage());
			}
			finally {
				if(con!=null)
					try {
						con.close();
					} catch (Exception e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
			}
			return orderDetails;
		}
		
	
	

	public static boolean completeOrder(String value0) throws SQLException{
		boolean rowDeleted;
		String complete = "complete";
		try(Connection con = DBConnection.createConnection();//create connection
				//create statement
				PreparedStatement Statement = con.prepareStatement(COMPLETE_ORDER)) {
			Statement.setString(1,complete);
			Statement.setString(2,value0);
			rowDeleted = Statement.executeUpdate() > 0;
		}
		return rowDeleted;
	}

	//DELETE cart deleteBook(value0)
	public boolean deleteCart(String username) throws SQLException{
		boolean rowDeleted;
		try(Connection con = DBConnection.createConnection();//create connection
				//create statement
				PreparedStatement Statement = con.prepareStatement(DELETE_CART)) {
			Statement.setString(1,username);
			rowDeleted = Statement.executeUpdate() > 0;
		}
		return rowDeleted;
	}

	public static List<OrderBean> getHistoryData(String username1) throws IOException {
		List<OrderBean> history = new ArrayList<>();
		//Connection con1 = null;
		
		Connection con = DBConnection.createConnection();
		PreparedStatement pstmt = null;
		if (con != null) {
			try { 
				pstmt = con.prepareStatement(GET_HISTORY);
				pstmt.setString(1,username1);
				ResultSet rs = pstmt.executeQuery();
				while (rs.next()) { 
					String orderId = rs.getString("orderId");
					String payId = rs.getString("payId");
					String username = rs.getString("username");
					String isbn = rs.getString("isbn");
					String date = rs.getString("date");
					String total = rs.getString("total");
					String status = rs.getString("status");
					history.add(new OrderBean(orderId, payId, username, isbn, date, total, status));
					System.out.println(history);
				}
			} catch (SQLException e) {
				e.printStackTrace();
				System.out.println("ERROR: Cannot Retrieve Books");
				//return new List<OrderBean>();
			}
			finally {
				if(con!=null)
					try {
						con.close();
					} catch (SQLException e) {
						System.out.println(e.getMessage());
					}
			}
			
		}return history  ;
		}
		public static float getIncome() throws SQLException{
			String complete = "complete";
			float x = 0;
			try(Connection con = DBConnection.createConnection();//create connection
				//create statement
				PreparedStatement Statement = con.prepareStatement("SELECT SUM(orders.total) as tot FROM orders WHERE status = ?")) {
				Statement.setString(1,complete);
				ResultSet rs = Statement.executeQuery();
				while (rs.next()) {
					String totString = rs.getString("tot");
					try {
						float tot = Float.parseFloat(totString);
						x += tot;
					} catch (NumberFormatException e) {
						System.out.println("Could not parse " + totString + " as a float.");
					}
				}
		} catch (SQLException e) {
			e.printStackTrace();
			System.out.println("ERROR: Cannot Retrieve price");
			//return new List<OrderBean>();
		}
		finally {
			if(con!=null)
				try {
					con.close();
				} catch (SQLException e) {
					System.out.println(e.getMessage());
				}
		}
			return x;
		}
	}

