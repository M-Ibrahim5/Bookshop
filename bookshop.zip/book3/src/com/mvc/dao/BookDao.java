package com.mvc.dao;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.sql.*;
import java.util.ArrayList;
import java.util.Base64;
import java.util.List;

import javax.sql.DataSource;

import com.mvc.bean.BookBean;
import com.mvc.util.DBConnection;

public class BookDao{
	
    private static final String SELECT_ALL_CUSTOMER = "SELECT * FROM customer";
	private static final String UPDATE_BOOK_DETAILS = "update book set title = ? , author = ? , publisher = ? , price = ? , keyword = ? , category = ? , description = ? , stock = ? , image = ? where isbn = ?";
	private static final String DELETE_BOOK = "delete from book where isbn =?";
	private static final String DELETE_CART = "delete from cart where isbn = ? and username = ? and quantity = ? ";
	private static final String ADD_BOOK_SQL = "INSERT INTO book (isbn, title, author, publisher, price, keyword, category, description, stock, image) VALUES (?,?,?,?,?,?,?,?,?,?)";
	private static final String ADD_CART_SQL = "INSERT INTO cart (username,isbn,quantity,bookPrice) VALUES (?,?,?,?)";
	private static final String GET_BOOK = "SELECT title, price FROM book where isbn=?";
	private static final String GET_BOOK_CART = "SELECT cart.isbn, cart.quantity, book.title, book.price FROM cart JOIN book ON cart.isbn = book.isbn WHERE username = ?";
	private static final String GET_TOTAL = "SELECT SUM(book.price * cart.quantity) as total_price FROM book JOIN cart ON book.isbn = cart.isbn WHERE cart.username = ?";

	public static final String url="jdbc:mysql://localhost:3306/userdata";
	public static final String username="root";
	public static final String password="satulapan#123";

    private Connection connection;

    Connection con = null;
	
	public BookDao() {
		
	}
    
	//-------------------------------------------------------------------------

    public static List<BookBean> getBookDetails() throws IOException {
		List<BookBean> BookDetails = new ArrayList<>();
		//Connection con1 = null;
		
		Connection con = DBConnection.createConnection();
		PreparedStatement pstmt = null;
		if (con != null) {
			try { 
				pstmt = con.prepareStatement("SELECT * FROM book");
				ResultSet rs = pstmt.executeQuery();
				while (rs.next()) {
					String isbn = rs.getString("isbn");
					String title = rs.getString("title");
					String author = rs.getString("author");
					String publisher = rs.getString("publisher");
					String price = rs.getString("price");
					String keyword = rs.getString("keyword");
					String category = rs.getString("category");
					String description = rs.getString("description");
					String stock = rs.getString("stock");
					String image = rs.getString("image");
					BookDetails.add(new BookBean(isbn,title,author,publisher,price,keyword,category,description,stock,image));
					System.out.println("BookDetails");
				}
			} catch (SQLException e) {
				e.printStackTrace();
				System.out.println("ERROR: Cannot Retrieve Books");
				//return new List<BookBean>();
			}
			finally {
				if(con!=null)
					try {
						con.close();
					} catch (SQLException e) {
						System.out.println(e.getMessage());
					}
			}
			
		}return BookDetails;
		}


    public static List<BookBean> getBookDetails3(String search) throws IOException {
		List<BookBean> BookDetails = new ArrayList<>();
		//Connection con1 = null;
		
		Connection con = DBConnection.createConnection();
		PreparedStatement pstmt = null;
		if (con != null) {
			try { 
				pstmt = con.prepareStatement("SELECT * FROM book where title = ? OR keyword = ? ");
				pstmt.setString(1,search);
				pstmt.setString(2,search);

				ResultSet rs = pstmt.executeQuery();
				while (rs.next()) {
					String isbn = rs.getString("isbn");
					String title = rs.getString("title");
					String author = rs.getString("author");
					String publisher = rs.getString("publisher");
					String price = rs.getString("price");
					String keyword = rs.getString("keyword");
					String category = rs.getString("category");
					String description = rs.getString("description");
					String stock = rs.getString("stock");
					String image = rs.getString("image");
					BookDetails.add(new BookBean(isbn,title,author,publisher,price,keyword,category,description,stock,image));
					System.out.println("BookDetails");
				}
			} catch (SQLException e) {
				e.printStackTrace();
				System.out.println("ERROR: Cannot Retrieve Books");
				//return new List<BookBean>();
			}
			finally {
				if(con!=null)
					try {
						con.close();
					} catch (SQLException e) {
						System.out.println(e.getMessage());
					}
			}
			
		}return BookDetails;
		}

		public static List<BookBean> getBookDetail(String isbn) throws IOException {
			List<BookBean> BookDetails = new ArrayList<>();
			//Connection con1 = null;
			
			Connection con = DBConnection.createConnection();
			PreparedStatement pstmt = null;
			if (con != null) {
				try {
					pstmt = con.prepareStatement(GET_BOOK);
					pstmt.setString(1,isbn);
					ResultSet rs = pstmt.executeQuery();
					while (rs.next()) {
						String title = rs.getString("title");
						String price = rs.getString("price");
						BookDetails.add(new BookBean(isbn,title,price));
						System.out.println(BookDetails);
					}
				} catch (SQLException e) {
					e.printStackTrace();
					System.out.println("ERROR: Cannot Retrieve Books");
					//return new List<BookBean>();
				}
				finally {
					if(con!=null)
						try {
							con.close();
						} catch (SQLException e) {
							System.out.println(e.getMessage());
						}
				}
				
			}return BookDetails;
			}
		public static List<BookBean> getBookDetail4(String isbn) throws IOException {
			List<BookBean> BookDetails = new ArrayList<>();
			//Connection con1 = null;
			
			Connection con = DBConnection.createConnection();
			PreparedStatement pstmt = null;
			if (con != null) {
				try {
					pstmt = con.prepareStatement(GET_BOOK);
					pstmt.setString(1,isbn);
					ResultSet rs = pstmt.executeQuery();
					while (rs.next()) {
						String title = rs.getString("title");
						String price = rs.getString("price");
						BookDetails.add(new BookBean(isbn,title,price));
						System.out.println(BookDetails);
					}
				} catch (SQLException e) {
					e.printStackTrace();
					System.out.println("ERROR: Cannot Retrieve Books");
					//return new List<BookBean>();
				}
				finally {
					if(con!=null)
						try {
							con.close();
						} catch (SQLException e) {
							System.out.println(e.getMessage());
						}
				}
				
			}return BookDetails;
			}
		
		
			public static List<BookBean> getBookDetailCart(String username) throws IOException {
			List<BookBean> BookDetails = new ArrayList<>();
			//Connection con1 = null;
			
			Connection con = DBConnection.createConnection();
			PreparedStatement pstmt = null;
			if (con != null) {
				try { 
					pstmt = con.prepareStatement(GET_BOOK_CART);
					pstmt.setString(1,username);
					ResultSet rs = pstmt.executeQuery();
					while (rs.next()) {
						String isbn = rs.getString("isbn");
						String title = rs.getString("title");
						String price = rs.getString("price");
						String quantity = rs.getString("quantity");
						BookDetails.add(new BookBean(isbn,title,price,quantity));
						System.out.println(BookDetails);
					}
				} catch (SQLException e) {
					e.printStackTrace();
					System.out.println("ERROR: Cannot Retrieve Books");
					//return new List<BookBean>();
				}
				finally {
					if(con!=null)
						try {
							con.close();
						} catch (SQLException e) {
							System.out.println(e.getMessage());
						}
				}
				
			}return BookDetails  ;
			}
			public static List<BookBean> getIsbnCart(String username) throws IOException {
			List<BookBean> BookDetails = new ArrayList<>();
			//Connection con1 = null;
			
			Connection con = DBConnection.createConnection();
			PreparedStatement pstmt = null;
			if (con != null) {
				try { 
					pstmt = con.prepareStatement(GET_BOOK_CART);
					pstmt.setString(1,username);
					ResultSet rs = pstmt.executeQuery();
					while (rs.next()) {
						String isbn = rs.getString("isbn");
						BookDetails.add(new BookBean(isbn));
						System.out.println(BookDetails);
					}
				} catch (SQLException e) {
					e.printStackTrace();
					System.out.println("ERROR: Cannot Retrieve Books");
					//return new List<BookBean>();
				}
				finally {
					if(con!=null)
						try {
							con.close();
						} catch (SQLException e) {
							System.out.println(e.getMessage());
						}
				}
				
			}return BookDetails  ;
			}

		//ADD Book
	public static String addBook(BookBean book){
		System.out.println(ADD_BOOK_SQL);
		try (Connection con = DBConnection.createConnection();
			PreparedStatement preparedStatement = con.prepareStatement(ADD_BOOK_SQL)) {
			preparedStatement.setString(1, book.getIsbn());
			preparedStatement.setString(2, book.getTitle());
			preparedStatement.setString(3, book.getAuthor());
			preparedStatement.setString(4, book.getPublisher());
			preparedStatement.setString(5, book.getPrice());
			preparedStatement.setString(6,book.getKeyword());
			preparedStatement.setString(7,book.getCategory());
			preparedStatement.setString(8,book.getDescription());
			preparedStatement.setString(9,book.getStock());
			preparedStatement.setString(10,book.getImage());
			System.out.println(preparedStatement);
			int i= preparedStatement.executeUpdate();
            
            if (i!=0)  //Just to ensure data has been inserted into the database
            return "SUCCESS"; 
			
		}catch (SQLException e) {
			e.printStackTrace();
		}
		return "Oops.. Something went wrong there..!";
	}

	

	//Edit Book Details
public boolean editbookDetails(BookBean book) throws SQLException, ClassNotFoundException{
		
	boolean rowUpdated = false;
	
	try (Connection con = DBConnection.createConnection();//create connection
			//create statement
		PreparedStatement Statement = con.prepareStatement(UPDATE_BOOK_DETAILS)) {
		System.out.println("Edit book Details :"+ Statement);
		Statement.setString(1, book.getIsbn());
		Statement.setString(2, book.getTitle());
		Statement.setString(3, book.getAuthor());
		Statement.setString(4, book.getPublisher());
		Statement.setString(5, book.getPrice());
		Statement.setString(6, book.getKeyword());
		Statement.setString(7, book.getCategory());
		Statement.setString(8, book.getDescription());
		Statement.setString(9, book.getStock());
		Statement.setString(10,book.getImage());
		
		System.out.println("Edit book Details :"+ Statement);
		rowUpdated = Statement.executeUpdate() > 0;	
		System.out.println(rowUpdated + "" + username);
	}
	catch (SQLException e) {
		System.out.println(e.getMessage());
	}
	finally {
		if(con!=null)
			try {
				con.close();
			} catch (SQLException e) {
				System.out.println(e.getMessage());
			}
	}
	return rowUpdated;
}

	//DELETE Book deleteBook(value0)
	public boolean deleteBook(String id1) throws SQLException{
		boolean rowDeleted;
		try(Connection con = DBConnection.createConnection();//create connection
				//create statement
				PreparedStatement Statement = con.prepareStatement(DELETE_BOOK)) {
			Statement.setString(1,id1);
			rowDeleted = Statement.executeUpdate() > 0;
		}
		return rowDeleted;
	}
	public boolean deleteCart(String isbn,String username,String quantity) throws SQLException{
		boolean rowDeleted;
		try(Connection con = DBConnection.createConnection();//create connection
				//create statement
			PreparedStatement Statement = con.prepareStatement(DELETE_CART)) {
			Statement.setString(1,isbn);
			Statement.setString(2,username);
			Statement.setString(3,quantity);
			System.out.println(Statement.toString());
			rowDeleted = Statement.executeUpdate() > 0;
		}
		return rowDeleted;
	}

	//add cart
	public static String addCart(String username,String isbn,String quantity,String price){
		System.out.println(ADD_CART_SQL);
		try (Connection con = DBConnection.createConnection();
			PreparedStatement preparedStatement = con.prepareStatement(ADD_CART_SQL)) {
			preparedStatement.setString(1, username);
			preparedStatement.setString(2, isbn);
			preparedStatement.setString(3, quantity);
			preparedStatement.setString(4, price);
			
			System.out.println(preparedStatement);
			int i= preparedStatement.executeUpdate();
            
            if (i!=0)  //Just to ensure data has been inserted into the database
            return "SUCCESS"; 
			
		}catch (SQLException e) {
			e.printStackTrace();
		}
		return "Oops.. Something went wrong there..!";
	}


	public static float getTotal(String username) throws IOException {
		Float tot = null;
		String tot1 = null;
		//Connection con1 = null;
		
		Connection con = DBConnection.createConnection();
		PreparedStatement pstmt = null;
		if (con != null) {
			try {
				pstmt = con.prepareStatement(GET_TOTAL);
				pstmt.setString(1,username);
				ResultSet rs = pstmt.executeQuery();
				while (rs.next()) {
					tot1 = rs.getString("total_price");
					System.out.println(tot1);
				}
				tot = Float.parseFloat(tot1);
				System.out.println(" tot = "+tot);
			} catch (SQLException e) {
				e.printStackTrace();
				System.out.println("ERROR: Cannot Retrieve Books");
				//return new List<BookBean>();
			}
			finally {
				if(con!=null)
					try {
						con.close();
					} catch (SQLException e) {
						System.out.println(e.getMessage());
					}
			}
			
		}return tot  ;
		}
	
	
		public static float getLinePrice(String quantity,String price) throws IOException {
		float quantity1 = Float.parseFloat(quantity);
		float price1 = Float.parseFloat(price);
		float linePrice = quantity1 * price1;
		return linePrice;
		}



}