package com.mvc.dao;

import java.sql.*;
import com.mvc.bean.RegisterBean;
import com.mvc.util.DBConnection;

public class RegisterDao {
    public String registerUser(RegisterBean registerBean) {
        String userName = registerBean.getUserName();
        String password = registerBean.getPassword();
        String email = registerBean.getEmail();
        String phone = registerBean.getPhone();
        String address = registerBean.getAddress();
        String age = registerBean.getAge();

        try {
            Connection con = DBConnection.createConnection();
            String query = "INSERT INTO customer (id,username,email,address,phone,password,age) values (NULL,?,?,?,?,?,?)"; // Insert
                                                                                                             // user
                                                                                                             // details
                                                                                                             // into the
                                                                                                             // table
                                                                                                             // 'USERS'
            PreparedStatement preparedStatement = con.prepareStatement(query); // Making use of prepared statements here
                                                                               // to insert bunch of data
            preparedStatement.setString(1, userName);
            preparedStatement.setString(2, email);
            preparedStatement.setString(3, address);
            preparedStatement.setString(4, phone);
            preparedStatement.setString(5, password);
            preparedStatement.setString(6, age);

            int i = preparedStatement.executeUpdate();

            if (i != 0) // Just to ensure data has been inserted into the database
                return "SUCCESS";
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return "Oops.. Something went wrong there..!"; // On failure, send a message from here.
    }
}