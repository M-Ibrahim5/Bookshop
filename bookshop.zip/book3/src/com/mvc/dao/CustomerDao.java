package com.mvc.dao;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

import javax.sql.DataSource;

import com.mvc.bean.CustomerBean;
import com.mvc.util.DBConnection;

public class CustomerDao{

    private static final String ViewCustomer = "SELECT SELECT id, username, email, address, phone, password, age FROM customer";
    private static final String SELECT_ALL_CUSTOMER = "SELECT * FROM customer";
	private static final String UPDATE_CUSTOMER_DETAILS = "update customer set username = ?, email = ? , address = ?, phone = ?, password = ? , age = ? where id = ?";
	private static final String DELETE_CUSTOMER = "delete from customer where id =?";

	public static final String url="jdbc:mysql://localhost:3306/userdata";
	public static final String username="root";
	public static final String password="satulapan#123";

    private Connection connection;

    Connection con = null;
	
	public CustomerDao() {
		
	}
    //SELECT ALL Course - Aggregation 
	public List<CustomerBean> selectAllCustomer () {
		List<CustomerBean> allCustomer = new ArrayList<>();
		try (Connection con = DBConnection.createConnection();//create connection
				//create statement
				//connection = DriverManager.getConnection(connectionUrl+dbName, userId, password);
				Statement statement=con.createStatement();
				ResultSet rs = statement.executeQuery(ViewCustomer)){
			//Statement statement = con.prepareStatement(ViewCustomer)) {
			//System.out.println(preparedStatement);
			//ResultSet rs = statement.executeQuery();
			// process the ResultSet object
			while (rs.next()) {
				String id = rs.getString("id");
				String username = rs.getString("username");
				String email = rs.getString("email");
				String address = rs.getString("address");
				String phone = rs.getString("phone");
				String password = rs.getString("password");
				String age = rs.getString("age");
				allCustomer.add(new CustomerBean(id,username,email,address,phone,password,age));
			}
		}catch (SQLException e) {
			e.printStackTrace();
		}
		return allCustomer;
	}
	public List<CustomerBean> selectAllCustomer4 () {
		List<CustomerBean> allCustomer4 = new ArrayList<>();
		Connection con = DBConnection.createConnection();
		PreparedStatement pstmt = null;
		if (con != null) {
			try {
				pstmt = con.prepareStatement("SELECT * FROM customer");
				ResultSet rs = pstmt.executeQuery();
				while (rs.next()) {
					String id = rs.getString("id");
					String username = rs.getString("username");
					String email = rs.getString("email");
					String address = rs.getString("address");
					String phone = rs.getString("phone");
					String password = rs.getString("password");
					String age = rs.getString("age");
					allCustomer4.add(new CustomerBean(id,username,email,address,phone,password,age));
				}
				if (rs != null)
					rs.close();
				if (pstmt != null)
					pstmt.close();
			} catch (SQLException e) {
				e.printStackTrace();
				System.out.println("ERROR: Cannot Retrieve Books");
				//return new List<CustomerBean>();
			}
		}
		System.out.println("No Connection...");
		return allCustomer4;
	}

    public static List<CustomerBean> getAllCustomers() {
        List<CustomerBean> customers = new ArrayList<>();
        try (Connection con = DBConnection.createConnection();//create connection
				//create statement
			PreparedStatement preparedStatement = con.prepareStatement(ViewCustomer)) {
			System.out.println(preparedStatement);
			ResultSet rs = preparedStatement.executeQuery();
			// process the ResultSet object
			while (rs.next()) {
				
				String id = rs.getString("id");
                String username = rs.getString("username");
                String email = rs.getString("email");
                String address = rs.getString("address");
                String phone = rs.getString("phone");
                String password = rs.getString("password");
                String age = rs.getString("age");
				customers.add(new CustomerBean (id, username, email, address, phone, password, age));
				System.out.println(customers);
			}
		}catch (SQLException e) {
			e.printStackTrace();
		}
		return customers;
	}


    public CustomerBean getCustomer(String id) throws SQLException {
        PreparedStatement preparedStatement = connection.prepareStatement("SELECT * FROM customer WHERE id=?");
        preparedStatement.setString(1, id);
        ResultSet resultSet = preparedStatement.executeQuery();
        if (resultSet.next()) {
            String username = resultSet.getString("username");
            String email = resultSet.getString("email");
            String address = resultSet.getString("address");
            String phone = resultSet.getString("phone");
            String password = resultSet.getString("password");
            String age = resultSet.getString("age");
            return new CustomerBean(id, username, email, address, phone, password, age);
        }
        return null;
    }

    public boolean updateCustomer(CustomerBean customer) throws SQLException {
        PreparedStatement preparedStatement = connection.prepareStatement("UPDATE customer SET username=?, email=?, address=?, phone=?, password=?, age=? WHERE id=?");
        preparedStatement.setString(1, customer.getUserName());
        preparedStatement.setString(2, customer.getEmail());
        preparedStatement.setString(3, customer.getAddress());
        preparedStatement.setString(4, customer.getPhone());
        preparedStatement.setString(5, customer.getPassword());
        preparedStatement.setString(6, customer.getAge());
        preparedStatement.setString(7, customer.getId());
        return preparedStatement.executeUpdate() > 0;
    }

	public List<CustomerBean> selectAllCustomer2 () {
	List<CustomerBean> allCustomer = new ArrayList<>();
		
		try (Connection con = DBConnection.createConnection();//create connection
				//create statement
			PreparedStatement preparedStatement = con.prepareStatement(SELECT_ALL_CUSTOMER)) {
			System.out.println(preparedStatement);
			ResultSet rs = preparedStatement.executeQuery();
			// process the ResultSet object
			while (rs.next()) {
				String custId = rs.getString("id");
				String username = rs.getString("username");
				String email = rs.getString("email");
				String address = rs.getString("address");
				String phone = rs.getString("phone");
				String password = rs.getString("password");
				String age = rs.getString("age");
				allCustomer.add(new CustomerBean(custId,username,email,address,phone,password,age));
			}
		}catch (SQLException e) {
			e.printStackTrace();
		}
		return allCustomer;
	}

    
    
    public static ArrayList<CustomerBean> getCustomer() {
		ArrayList<CustomerBean> allCustomer = new ArrayList<CustomerBean>();

/* 		con = getConnection();
 */     Connection con = DBConnection.createConnection();
 		PreparedStatement pstmt = null;

		if (con != null) {
			try {
				String getAllCustomer = "SELECT * FROM customer;";
				pstmt = con.prepareStatement(getAllCustomer);

				ResultSet rs = pstmt.executeQuery();
				while (rs.next()) {
				String id = rs.getString("id");
                String username = rs.getString("username");
                String email = rs.getString("email");
                String address = rs.getString("address");
                String phone = rs.getString("phone");
                String password = rs.getString("password");
                String age = rs.getString("age");
				allCustomer.add(new CustomerBean (id, username, email, address, phone, password, age));
				System.out.println(allCustomer);
				}

				if (rs != null)
					rs.close();
				if (pstmt != null)
					pstmt.close();
			} catch (SQLException e) {
				e.printStackTrace();
				return new ArrayList<CustomerBean>();
			}
		}else 
			System.out.println("con = null");
		return allCustomer;
	}
        
    public static List<CustomerBean> getCustomerDetails() {
		List<CustomerBean> customerDetails = new ArrayList<>();
		 Connection con1 = null;
	
		
		try {
			Class.forName("com.mysql.jdbc.Driver");
			con1= DriverManager.getConnection(url,username,password);
			String insertQuery="select * from customer";
			PreparedStatement ps = con1.prepareStatement(insertQuery);
			ResultSet rs1 =ps.executeQuery();
			
			while(rs1.next()){
				CustomerBean customer = new CustomerBean();
				customer.setId(rs1.getString(1));
				customer.setUserName(rs1.getString(2));
				customer.setEmail(rs1.getString(3));
				customer.setAddress(rs1.getString(4));;
				customer.setPhone(rs1.getString(5));
				customer.setpassword(rs1.getString(6));
				customer.setAge(rs1.getString(7));
				customerDetails.add(customer);
			}
		} catch (ClassNotFoundException | SQLException e) {
			System.out.println(e.getMessage());
		}
		finally {
			if(con1!=null)
				try {
					con1.close();
				} catch (SQLException e) {
					System.out.println(e.getMessage());
				}
		}
		return customerDetails;
	}

    public static List<CustomerBean> getCustomerDetails1(String username) {
		List<CustomerBean> customerDetails = new ArrayList<>();
		Connection con1 = null;
		try {
			Class.forName("com.mysql.jdbc.Driver");
			con1= DriverManager.getConnection(url,username,password);
			String insertQuery="select * from customer where username = ?";
			PreparedStatement ps = con1.prepareStatement(insertQuery);
			ps.setString(1,username);
			ResultSet rs1 =ps.executeQuery();
			
			while(rs1.next()){
				CustomerBean customer = new CustomerBean();
				customer.setId(rs1.getString(1));
				customer.setUserName(rs1.getString(2));
				customer.setEmail(rs1.getString(3));
				customer.setAddress(rs1.getString(4));;
				customer.setPhone(rs1.getString(5));
				customer.setpassword(rs1.getString(6));
				customer.setAge(rs1.getString(7));
				customerDetails.add(customer);
			}
		} catch (ClassNotFoundException | SQLException e) {
			System.out.println(e.getMessage());
		}
		finally {
			if(con1!=null)
				try {
					con1.close();
				} catch (SQLException e) {
					System.out.println(e.getMessage());
				}
		}
		return customerDetails;
	}
    
	public static CustomerBean getCustomerDetails2(String username) {
		CustomerBean customer = new CustomerBean();
		Connection con1 = null;
		try {
			Class.forName("com.mysql.jdbc.Driver");
			con1= DriverManager.getConnection(url,username,password);
			String insertQuery="select * from customer where username = ?";
			PreparedStatement ps = con1.prepareStatement(insertQuery);
			ps.setString(1,username);
			ResultSet rs1 =ps.executeQuery();
			
			while(rs1.next()){
				//CustomerBean customer = new CustomerBean();
				customer.setId(rs1.getString(1));
				customer.setUserName(rs1.getString(2));
				customer.setEmail(rs1.getString(3));
				customer.setAddress(rs1.getString(4));;
				customer.setPhone(rs1.getString(5));
				customer.setpassword(rs1.getString(6));
				customer.setAge(rs1.getString(7));
				//customer=customer;
			}
		} catch (ClassNotFoundException | SQLException e) {
			System.out.println(e.getMessage());
		}
		finally {
			if(con1!=null)
				try {
					con1.close();
				} catch (SQLException e) {
					System.out.println(e.getMessage());
				}
		}
		return customer;
	}

//Edit Customer Details
public boolean editCustomerDetails(CustomerBean customer) throws SQLException, ClassNotFoundException{
		
	boolean rowUpdated = false;
	
	try (Connection con = DBConnection.createConnection();//create connection
			//create statement
		PreparedStatement Statement = con.prepareStatement(UPDATE_CUSTOMER_DETAILS)) {
		System.out.println("Edit customer Details :"+ Statement);
		Statement.setString(1, customer.getUserName());
		Statement.setString(2, customer.getEmail());
		Statement.setString(3, customer.getAddress());
		Statement.setString(4, customer.getPhone());
		Statement.setString(5, customer.getPassword());
		Statement.setString(6, customer.getAge());
		Statement.setString(7, customer.getId());
		
		System.out.println("Edit customer Details :"+ Statement);
		rowUpdated = Statement.executeUpdate() > 0;	
		System.out.println(rowUpdated + "" + username);
	}
	catch (SQLException e) {
		System.out.println(e.getMessage());
	}
	finally {
		if(con!=null)
			try {
				con.close();
			} catch (SQLException e) {
				System.out.println(e.getMessage());
			}
	}
	return rowUpdated;
}


//DELETE Customer deleteCustomer(value0)
public boolean deleteCustomer(String id1) throws SQLException{
	boolean rowDeleted;
	try(Connection con = DBConnection.createConnection();//create connection
			//create statement
			PreparedStatement Statement = con.prepareStatement(DELETE_CUSTOMER)) {
		Statement.setString(1,id1);
		rowDeleted = Statement.executeUpdate() > 0;
	}
	return rowDeleted;
}
}